var make = require('./make_');
var arrContains = require('../array/contains');
var objContains = require('../object/contains');

    /**
     */
    module.exports = make(arrContains, objContains);


