define(function(require){

//automatically generated, do not edit!
//run `node build` instead
return {
    'convert' : require('./time/convert'),
    'now' : require('./time/now'),
    'parseMs' : require('./time/parseMs'),
    'toTimeString' : require('./time/toTimeString')
};

});
