define(function () {
    var UNDEF;

    /**
     */
    function isUndef(val){
        return val === UNDEF;
    }
    return isUndef;
});
