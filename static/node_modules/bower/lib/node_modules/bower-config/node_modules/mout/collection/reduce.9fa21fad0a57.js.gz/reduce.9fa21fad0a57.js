var make = require('./make_');
var arrReduce = require('../array/reduce');
var objReduce = require('../object/reduce');

    /**
     */
    module.exports = make(arrReduce, objReduce);


