var make = require('./make_');
var arrSome = require('../array/some');
var objSome = require('../object/some');

    /**
     */
    module.exports = make(arrSome, objSome);


