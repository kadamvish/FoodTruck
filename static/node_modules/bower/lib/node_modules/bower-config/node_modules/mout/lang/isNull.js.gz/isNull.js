
    /**
     */
    function isNull(val){
        return val === null;
    }
    module.exports = isNull;


