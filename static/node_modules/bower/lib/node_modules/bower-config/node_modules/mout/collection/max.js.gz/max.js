var make = require('./make_');
var arrMax = require('../array/max');
var objMax = require('../object/max');

    /**
     * Get maximum value inside collection
     */
    module.exports = make(arrMax, objMax);


