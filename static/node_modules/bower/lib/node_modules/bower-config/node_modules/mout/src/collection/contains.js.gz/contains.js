define(['./make_', '../array/contains', '../object/contains'], function (make, arrContains, objContains) {

    /**
     */
    return make(arrContains, objContains);

});
