

//automatically generated, do not edit!
//run `node build` instead
module.exports = {
    'convert' : require('./time/convert'),
    'now' : require('./time/now'),
    'parseMs' : require('./time/parseMs'),
    'toTimeString' : require('./time/toTimeString')
};


