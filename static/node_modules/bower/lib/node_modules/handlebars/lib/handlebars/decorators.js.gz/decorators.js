import registerInline from './decorators/inline';

export function registerDefaultDecorators(instance) {
  registerInline(instance);
}

