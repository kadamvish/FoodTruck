define(['./make_', '../array/every', '../object/every'], function (make, arrEvery, objEvery) {

    /**
     */
    return make(arrEvery, objEvery);

});
